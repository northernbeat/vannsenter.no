<?php

// FIXME: Easer to just remove the content inside these functions for now,
// instead of finding the places they are used.

if (!function_exists("twentytwenty_generate_css")) {
	function twentytwenty_generate_css($selector, $style, $value, $prefix = "", $suffix = "", $echo = true)
    {
    }
}

if (!function_exists("twentytwenty_get_customizer_css")) {
 	function twentytwenty_get_customizer_css($type = "front-end")
    {
    }
}
